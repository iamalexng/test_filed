package com.bs.fshop.po;
/**
 * @title:
 * @descrption: 所有po都继承这个类，便于共同的部分，进行统一修改
 * @team:
 * @className AllParent.java
 * @author 吴圣(890160)
 * @createDate 创建时间：2015-9-30 下午3:07:53
 * 
 */
public abstract class AllParent extends AbstractMvcfshop {

	/**
	 * 随机序列号
	 */
	private static final long serialVersionUID = 6287752419459793955L;
	
}
