package com.bs.fshop.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @title:
 * @descrption: 
 * @team:
 * @className DNIRecord.java
 * @author 吴圣(890160)
 * @createDate 创建时间：2017-2-20 上午8:12:08
 * 
 */

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DNIRecord {

}
