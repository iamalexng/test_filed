package com.yudean.itc.bean;

/**
 * Created by 890157 on 2016/6/1.
 */
public class PrivOrigin {
    private String type;
    private String id;
    private String name;

    public PrivOrigin(String type, String id, String name){
        this.type = type;
        this.id = id;
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
