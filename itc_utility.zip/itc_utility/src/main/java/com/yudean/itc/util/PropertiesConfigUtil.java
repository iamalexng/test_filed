package com.yudean.itc.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import com.yudean.itc.bean.PropertiesConfig;
import com.yudean.itc.util.PropertiesUtils;
import com.yudean.itc.util.StringHelper;

public class PropertiesConfigUtil {

	/**
	 * 从配置文件中获取定义配置
	 * 
	 * @param propertiesName 文件路径
	 * @param propertiesFile 配置参数
	 * @return
	 */
	static public PropertiesConfig getConfig(String propertiesFile, String propertiesName) throws NullPointerException {
		final String _dec = ".";
		Properties properties = PropertiesUtils.getProperties(propertiesFile);
		String fieldToker = properties.getProperty(StringHelper.concat(propertiesName, _dec, "Field"));
		StringTokenizer token = new StringTokenizer(fieldToker, ",");
		List<String> fieldList = new ArrayList<String>();// 配置域数据列表
		while (token.hasMoreTokens()) {
			fieldList.add(token.nextToken());
		}
		token = new StringTokenizer(properties.getProperty(propertiesName), ",");
		Map<String, Map<String, String>> listMap = new HashMap<String, Map<String, String>>();
		while (token.hasMoreTokens()) {
			String argsName = token.nextToken();
			Map<String, String> FieldMap = new HashMap<String, String>();
			for (String field : fieldList) {
				String value = properties.getProperty(StringHelper.concat(propertiesName, _dec, argsName, _dec, field));
				FieldMap.put(field, value);
			}
			listMap.put(argsName, FieldMap);
		}
		PropertiesConfig propertiesConfig = new PropertiesConfig();
		propertiesConfig.setName(propertiesName);
		propertiesConfig.setFieldList(fieldList);
		propertiesConfig.setFieldDate(listMap);
		return propertiesConfig;
	}

	/**
	 * 获取定义配置域数据，并转换为数据对象
	 * 
	 * @param propertiesName
	 * @param propertiesFile
	 * @param fileName
	 * @param clazz
	 * @return
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	static public <T> T getConfigCastBean(String propertiesFile, String propertiesName, String argsName, Class<T> clazz) throws NullPointerException, InstantiationException,
			IllegalAccessException {
		Map<String, String> fieldMap = getConfig(propertiesFile, propertiesName).getFieldDate().get(argsName);
		T retObj = clazz.newInstance();
		if (null != fieldMap) {
			Field[] fields = clazz.getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				if (String.class.equals(field.getType())) {
					String fieldValue = fieldMap.get(field.getName());
					field.set(retObj, fieldValue);
				}
			}
		}
		return retObj;
	}

	/**
	 * 获取定义配置域数据，并转换为数据对象
	 * 
	 * @param propertiesName 文件路径
	 * @param propertiesFile 配置参数
	 * @param argsName 类别参数
	 * @param obj 数据反射类
	 * @return
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	static public Object getConfigCastBean(String propertiesFile, String propertiesName, String argsName, Object obj) throws NullPointerException, InstantiationException,
			IllegalAccessException {
		Map<String, String> fieldMap = getConfig(propertiesFile, propertiesName).getFieldDate().get(argsName);
		if (null != fieldMap) {
			Field[] fields = obj.getClass().getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				if (String.class.equals(field.getType())) {
					String fieldValue = fieldMap.get(field.getName());
					field.set(obj, fieldValue);
				}
			}
		}
		return obj;
	}

	/**
	 * 获取定义配置域数据，并转换为数据对象
	 * 
	 * @param propertiesName 文件路径
	 * @param propertiesFile 配置参数
	 * @param argsName 类别参数
	 * @param obj 数据反射类
	 * @return
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	static public Object getConfigCastBean(String propertiesFile, String propertiesName, String argsName, Class<?> clazz, Object obj) throws NullPointerException, InstantiationException,
			IllegalAccessException {
		Map<String, String> fieldMap = getConfig(propertiesFile, propertiesName).getFieldDate().get(argsName);
		if (null != fieldMap) {
			Field[] fields = clazz.getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				if (String.class.equals(field.getType())) {
					String fieldValue = fieldMap.get(field.getName());
					field.set(obj, fieldValue);
				}
			}
		}
		return obj;
	}
}
