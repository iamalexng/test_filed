package com.yudean.itc.util;

import java.util.Random;

/**
 * @company: gdyd
 * @className: UUIDGenerator.java
 * @author: 890166
 * @createDate: 2015-5-28
 * @updateUser: 890166
 * @version: 1.0
 */
public class UUIDGenerator {

	// 随机因子
	private final static char[] digits = { '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
			'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w',
			'x', 'y', 'z' };

	/**
	 * @description: 自定义位UUID 计算公式为 1-e^(-(10^10)^2/36^size) 循环生成100亿次出现冲突概率
	 *               得出结论是循环100亿次后再生成1256条后才会出现重复
	 * @author: 890166
	 * @createDate: 2015-5-28
	 * @param size
	 *            uuid长度
	 * @return:
	 */
	private static String getCustomUUID(int size) {
		// 获取随机实例
		Random random = new Random();
		char[] cArray = new char[size];
		for (int i = 0; i < size; i++) {
			cArray[i] = digits[random.nextInt(digits.length)];
		}
		return new String(cArray);
	}

	/**
	 * @description: 最后封装一次
	 * @author: 890166
	 * @createDate: 2015-5-28
	 * @return:
	 */
	public static String getUUID() {
		return getCustomUUID(16);
	}

}
