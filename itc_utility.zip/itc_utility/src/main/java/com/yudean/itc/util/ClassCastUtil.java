package com.yudean.itc.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 数据转换注入工具
 * 
 * @author kChen
 * 
 */
public class ClassCastUtil {

	static final private String M_NO_CAST_FIELD_Final = " final ";// 标记类域中的
																	// final关键字
	static private List<String> NO_CAST_FIELD_LIST;
	static{
		NO_CAST_FIELD_LIST = new ArrayList<String>();
		NO_CAST_FIELD_LIST.add("final");
		NO_CAST_FIELD_LIST.add("static");
	}
	/**
	 * 类型数据注入，child必需是parentObj的子类
	 * 
	 * @param child
	 * @param parentObj
	 * @return
	 * @throws IllegalAccessException
	 * @throws NoSuchFieldException
	 * @throws IllegalArgumentException
	 * @throws ClassCastException
	 * @throws SecurityException
	 * @throws InstantiationException
	 */
	@SuppressWarnings("unchecked")
	static public <T> T castParent2Child(Class<T> child, Object parentObj) throws InstantiationException, IllegalAccessException, SecurityException,
			IllegalArgumentException, NoSuchFieldException {
		T childObj = child.newInstance();
		childObj = (T) castParent2Child(childObj, parentObj);
		return childObj;
	}

	/**
	 * 类型数据注入 childObj必需是parentObj的子类
	 * 
	 * @param childObj
	 * @param parentObj
	 * @return
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws ClassCastException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	static public Object castParent2Child(Object childObj, Object parentObj) throws SecurityException, NoSuchFieldException,
			IllegalArgumentException, IllegalAccessException {
		Class<?> parentClass = parentObj.getClass();
		Class<?> childClass = childObj.getClass();
		boolean isRun = true;
		while (isRun) {// 探查区域
			if (childClass.equals(parentClass)) {
				isRun = false;
				break;
			}
			childClass = childClass.getSuperclass();
			if (childClass.equals(Object.class)) {
				throw new ClassCastException("非继承类");
			}
		}
		if (parentClass.isAssignableFrom(childObj.getClass())) {// 注入数据
			Field[] fields = parentClass.getDeclaredFields();
			for (int index = 0; index < fields.length; index++) {
				Field pField = fields[index];
				String filedName = pField.getName();
				Field cFidld = childClass.getDeclaredField(filedName);
				pField.setAccessible(true);
				cFidld.setAccessible(true);
				Object value = pField.get(parentObj);
				cFidld.set(childObj, value);
			}
		} else {
			throw new ClassCastException("非集继承类");
		}
		return childObj;
	}

	/**
	 * 注入继承树上的所有类给子类或相同类
	 * 
	 * @param child
	 * @param parentObj
	 * @return
	 * @throws SecurityException
	 * @throws ClassCastException
	 * @throws IllegalArgumentException
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	@SuppressWarnings("unchecked")
	static public <T> T castAllField2Class(Class<T> toCalss, Object fromObj) throws InstantiationException, IllegalAccessException,
			SecurityException, IllegalArgumentException, NoSuchFieldException {
		T toObj = toCalss.newInstance();
		toObj = (T) castAllField2Class(toObj, fromObj);
		return toObj;
	}

	/**
	 * 注入继承树上的所有类给子类或相同类
	 * 
	 * @param childObj
	 * @param parentObj
	 * @return
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws ClassCastException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	static public Object castAllField2Class(Object childObj, Object parentObj) throws SecurityException, NoSuchFieldException,
			IllegalArgumentException, IllegalAccessException {
		Class<?> parentClass = parentObj.getClass();
		Class<?> childClass = childObj.getClass();
		int Count = 0;
		while (!parentClass.equals(Object.class)) {// 向上层循环
			while (Count < 128) {// 复制当前域，如果域总量超过128，则不再复制。
				if (childClass.equals(parentClass)) {
					Count++;
					Field[] fields = parentClass.getDeclaredFields();
					for (int index = 0; index < fields.length; index++) {// 注入数据
						Field pField = fields[index];
						if (!pField.toGenericString().contains(M_NO_CAST_FIELD_Final)) {// 如果包含final字段，则不注入，否则会主动引发IllegalAccessException异常
							String filedName = pField.getName();
							Field cFidld = childClass.getDeclaredField(filedName);
							pField.setAccessible(true);
							cFidld.setAccessible(true);
							Object value = pField.get(parentObj);
							cFidld.set(childObj, value);
						}
					}
					break;
				}
				childClass = childClass.getSuperclass();
				if (childClass.equals(Object.class)) {
					throw new ClassCastException("非关系类");
				}
			}
			parentClass = parentClass.getSuperclass();
		}
		return childObj;
	}

	/**
	 * 注入继承树上的所有类给子类或相同类
	 * 
	 * @param child
	 * @param parentObj
	 * @return
	 * @throws SecurityException
	 * @throws ClassCastException
	 * @throws IllegalArgumentException
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	@SuppressWarnings("unchecked")
	static public <T> T castAllField2Class(Class<T> toCalss, Object fromObj, Class<T> endCalss) throws InstantiationException,
			IllegalAccessException, IllegalArgumentException, SecurityException, NoSuchFieldException {
		T toObj = toCalss.newInstance();
		toObj = (T) castAllField2Class(toObj, fromObj, endCalss);
		return toObj;
	}

	/**
	 * 注入继承树上的所有类给子类或相同类
	 * 
	 * @param childObj
	 * @param parentObj
	 * @param endCalss
	 *            注入截止类
	 * @return
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws ClassCastException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	static public <T> Object castAllField2Class(Object childObj, Object parentObj, Class<T> endCalss) throws IllegalArgumentException,
			IllegalAccessException, SecurityException, NoSuchFieldException {
		Class<?> parentClass = parentObj.getClass();
		Class<?> childClass = childObj.getClass();
		int Count = 0;
		while (!parentClass.equals(endCalss)) {
			while (Count < 128) {
				if (childClass.equals(parentClass)) {
					Count++;
					Field[] fields = parentClass.getDeclaredFields();
					for (int index = 0; index < fields.length; index++) {// 注入数据
						Field pField = fields[index];
						if (!pField.toGenericString().contains(M_NO_CAST_FIELD_Final)) {// 如果包含final字段，则不注入，否则会主动引发IllegalAccessException异常
							String filedName = pField.getName();
							Field cFidld = childClass.getDeclaredField(filedName);
							pField.setAccessible(true);
							cFidld.setAccessible(true);
							Object value = pField.get(parentObj);
							cFidld.set(childObj, value);
						}
					}
					break;
				}
				childClass = childClass.getSuperclass();
				if (childClass.equals(Object.class)) {
					throw new ClassCastException("非关系类");
				}
			}
			parentClass = parentClass.getSuperclass();
		}
		return childObj;
	}
	
	/**
	 * 将相同对象的数据拷贝，如果为null则不会修改
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-10-28
	 * @param fObj
	 * @param tObj
	 * @throws SecurityException
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException:
	 */
	static public void castNoNullFieldSingle(Object fObj, Object tObj) throws SecurityException, IllegalArgumentException, IllegalAccessException{
		Class<?> fclass = fObj.getClass();
		Class<?> tclass = tObj.getClass();
		if(fclass.equals(tclass)){
			Field[] fields = fclass.getDeclaredFields();
			for(Field field : fields){
				String declareFile = field.toGenericString();
				String[] declareSplit = declareFile.split(" ");
				List<String> declareList = Arrays.asList(declareSplit);
				if(checkNoContains(declareList)){
					field.setAccessible(true);
					Object data = field.get(fObj);
					if(null != data){
						field.set(tObj, data);
					}
				}
			}
		}else{
			throw new SecurityException("传入数据类型不一致");
		}
	}
	
	static private boolean checkNoContains(List<String> list){
		for(String strContain : NO_CAST_FIELD_LIST){
			if(list.contains(strContain)){
				return false;
			}
		}
		return true;
	}
}
