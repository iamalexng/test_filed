package com.yudean.itc.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

/**
 * 支援读写类，支持使用*作为通配符。传入的路径可以是相对路劲，也可以是绝对路径。 路径格式为/com/gdyd/timss/abc/*.class
 * 
 * @company: gdyd
 * @className: ResourceLoader.java
 * @author: kChen
 * @createDate: 2014-11-24
 * @updateUser: kChen
 * @version: 1.0
 */
public class ResourceLoader {
	private static final Logger LOG = Logger.getLogger(ResourceLoader.class);

	public enum Mode {
		Single, Mulit
	}

	static public String Single_Mode = "classpath:";
	static public String Mulit_Mode = "classpath*:";

	/**
	 * 获取路径下所有指定文件，可以用通配符
	 * 
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-11-25
	 * @param packagePath
	 * @return
	 * @throws IOException
	 *             :
	 */
	static public Set<Resource> getResources(String packagePath) throws IOException {
		return coverPackagesResource(packagePath, Mode.Mulit);
	}

	/**
	 * 获取路径下所有指定文件，可以用通配符，只获取扫描到的第一个
	 * 
	 * @param packagePath
	 * @return
	 * @throws IOException
	 */
	static public Set<Resource> getResource(String packagePath) throws IOException {
		return coverPackagesResource(packagePath, Mode.Single);
	}

	/**
	 * 获取所有指定路径的指定文件
	 * 
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-11-24
	 * @param packagePaths
	 * @return
	 * @throws IOException
	 * @throws Exception
	 *             :
	 */
	static public Set<Resource> getResources(Set<String> packagePaths) throws IOException {
		Set<Resource> retSet = new HashSet<Resource>();
		for (String packagePath : packagePaths) {
			retSet.addAll(coverPackagesResource(packagePath, Mode.Mulit));
		}
		return retSet;
	}

	/**
	 * 获取资源文件夹下的统配文件,会对file开头的路劲进行特殊处理
	 * 
	 * @param packagePaths
	 * @return
	 * @throws IOException
	 */
	static public Set<Resource> getWebResources(Set<String> packagePaths) throws IOException {
		ResourcePatternResolver resourceLoader = new PathMatchingResourcePatternResolver();
		Set<Resource> retSet = new HashSet<Resource>();
		for (String packagePath : packagePaths) {
			try {
				Resource[] sources = null;
				if(!packagePath.startsWith("file:")){
					packagePath = StringHelper.concat(Mulit_Mode, packagePath);
				}
				sources = resourceLoader.getResources(packagePath);
				for (Resource source : sources) {
					retSet.add(source);
				}
			} catch (FileNotFoundException e) {
				LOG.warn("获取文件路径异常", e);
			}
		}
		return retSet;
	}

	/**
	 * 获取所有指定路径的指定文件
	 * 
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-11-24
	 * @param packagePaths
	 * @param mode
	 *            指定是单个获取还是复数列表获取
	 * @return
	 * @throws IOException
	 * @throws Exception
	 *             :
	 */
	static public Set<Resource> getResources(List<String> packagePaths, Mode mode) throws IOException {
		Set<Resource> retSet = new HashSet<Resource>();
		for (String packagePath : packagePaths) {
			retSet.addAll(coverPackagesResource(packagePath, mode));
		}
		return retSet;
	}

	static private Set<Resource> coverPackagesResource(String packagePath, Mode mode) throws IOException {
		ResourcePatternResolver resourceLoader = new PathMatchingResourcePatternResolver();
		Resource[] sources = null;
		switch (mode) {
		case Single: {
			sources = resourceLoader.getResources(Single_Mode + packagePath);
			break;
		}
		case Mulit: {
			sources = resourceLoader.getResources(Mulit_Mode + packagePath);
			break;
		}
		default: {
			sources = resourceLoader.getResources(Mulit_Mode + packagePath);
			break;
		}
		}
		Set<Resource> retSet = new HashSet<Resource>();
		for (Resource source : sources) {
			retSet.add(source);
		}
		return retSet;
	}
}
