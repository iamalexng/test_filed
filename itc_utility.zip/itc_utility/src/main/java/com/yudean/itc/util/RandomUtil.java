package com.yudean.itc.util;

import java.nio.charset.Charset;
import java.util.Random;

import org.bouncycastle.util.encoders.UrlBase64;

/**
 * 伪随机数生成工具
 * @title: {title}
 * @description: {desc}
 * @company: gdyd
 * @className: RandomUtil.java
 * @author: kChen
 * @createDate: 2014-7-10
 * @updateUser: kChen
 * @version: 1.0
 */
public class RandomUtil {
	private static Random _random = null;

	static {
		Long seed = Math.round(Math.random()*100000);
		_random = new Random(seed);
	}

	static public String RandomStringNumber(int len) throws Exception {
		String random = "";
		while (true) {
			Long ran = Math.abs(_random.nextLong());
			random += ran.toString();
			if (random.length() > len) {
				random = random.substring(0, len);
				break;
			} else if (random.length() == len) {
				break;
			}
		}
		return random;
	}

	static public Long RandomLong(int len) throws Exception {
		String randomstr = RandomStringNumber(len);
		return Long.valueOf(randomstr);
	}
	
	static public byte[] RandomByte(int len) throws Exception {
		byte[] bit = new byte[len];
		_random.nextBytes(bit);
		return bit;
	}

	static public String RandomBase64URL(int len) throws Exception {
		return new String(UrlBase64.encode(RandomByte(len)), Charset.defaultCharset().name());
	}
}
