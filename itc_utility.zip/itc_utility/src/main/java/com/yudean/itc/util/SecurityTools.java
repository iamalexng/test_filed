package com.yudean.itc.util;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.log4j.Logger;

/**
 * 安全工具类，提供一个生成全局UUID，以及一个简单的封装用户信息的实现
 *
 * @author : DL<duanlei@gdyd.com>
 * @version : 1.0
 */
public class SecurityTools {

    //加密所用的SALT 生成地址为：https://api.wordpress.org/secret-key/1.1/salt/
    private final static String SALT = "YPBoEdRTuPB/+n)[E-D.V:4rqe!AjT1|bT5-AMPu+$k#S~Jb<HX:&{2dA[/*XZdS";
    //16进制映射
    private static String HEX = "0123456789ABCDEF";
    
    private static final Logger log = Logger.getLogger(SecurityTools.class);

    /**
     * 生成一个包含用户信息的token
     *
     * @param userID     用户信息标示
     * @param expireTime token有效期，秒为单位
     * @return
     */
    public static String getToken(String userID, long expireTime) {
        if (expireTime < 0) expireTime = 1000;
        StringBuilder sb = new StringBuilder();
        sb.append(userID).append("#").append(expireTime * 1000);
        String token = encrypt(sb.toString());
        return token;
    }
    
    /**
     * 使用最基本的校验判断是否是一个合法及未过期的token，<br/>
     * 如果开发者需要对token中携带的用户信息做进一步校验，需要调用<b>unWrapUserInfo()</b>方法
     * @param token
     * @return 如果是合法且未过期token，返回true
     */
    public boolean isValidToken(String token){
    	return (unWrapUserInfo(token) != null);
    }
    /**
     * 从Token中获取用户信息
     *
     * @param token
     * @return 调用者在生成Token时存入的用户信息
     */
    public static String unWrapUserInfo(String token) {
        if (token != null && !"".equals(token)) {
            try {
                String[] decrypted = decrypt(token).split("#");
                long tokenExpiredTime = Long.parseLong(decrypted[1]);
                long now = DateHelper.now().getTime();
                if(tokenExpiredTime < now)
                	throw new Exception("Token expired " + (now - tokenExpiredTime) / 1000 + " SEC ago");
                return decrypted[0];
           } catch (Exception e) {
            	log.error("Invaild token :" + token, e);
            }
        }
        return null;
    }

    /**
     * 延长Token过期时间
     *
     * @param oldToken
     * @param expireTime 单位为秒
     * @return
     */
    public static String extendToken(String oldToken, long expireTime) {
        if (expireTime < 0) expireTime = 1000;
        if (oldToken == null || "".equals(oldToken)) {
            return null;
        }
        String userInfo = unWrapUserInfo(oldToken);
        if (userInfo == null) {
            return null;
        }
        return getToken(userInfo, expireTime);
    }

    /**
     * 用来生成系统共用的UUID，出于安全的考虑，增加了一位的安全码
     *
     * @return
     */
    public static String getUUID() {
        String hex = IDGenerator.getHex().toUpperCase();
        char securityCode = buildSecurityCode(hex, 16);
        return hex + securityCode;
    }

    /**
     * 验证是否是合法的由getItcUUID生成的UUID
     *
     * @param uuid
     * @return
     */
    public static boolean isValidUUID(String uuid) {
        if (uuid.length() != 33) {
            return false;
        }
        String first32 = uuid.substring(0, 32);
        char lastOne = uuid.charAt(32);
        char securityCode = buildSecurityCode(first32, 16);
        if (lastOne == securityCode)
            return true;
        return false;
    }

    /**
     * 提供一个方法，要求提供一个源字符串
     *
     * @param src
     * @return
     */
    public static String encrypt(String src) {
        return CryptUtils.encrypt(src, SecurityTools.SALT);
    }

    /**
     * 还原原始的Token内容，如果不是由系统加密的token或者是非法的，就将异常抛出
     * 由调用者处理
     *
     * @param token
     * @return
     * @throws Exception token非法。
     */
    public static String decrypt(String token) throws Exception {
        if (token != null && !"".equals(token)) {
            return CryptUtils.decrypt(token, SecurityTools.SALT);
        }
        return null;
    }

    /**
     * 生成最后一位验证码
     *
     * @param str
     * @param size 16 或者 10
     * @return
     */
    private static char buildSecurityCode(String str, int size) {
        if (str == null || "".equals(str))
            return 0;
        if (size != 10 || size != 16) size = 16;

        byte[] bytes = str.getBytes();
        int result = 0;
        for (byte one : bytes) {
            //保证是正数
            result += (one & 0xff);
        }
        int mod = result % size;
        char securityCode = HEX.charAt(mod);
        return securityCode;
    }

    public static void main(String[] args) throws Exception {
        final String uuid = getUUID();
        System.out.println("Now let's build a UUID with verify Code:" + uuid);
        String uuidModified = "a" + uuid;
        System.out.println("Now modify the uuid to " + uuidModified + " , but the result verifing it is " + isValidUUID(uuidModified));

        String userID = "890117";
        long expireIn = 1000L;
        String userInfo = getToken(userID, expireIn);
        System.out.println(userID + " expire in " + expireIn + ": build token is-" + userInfo);

        String user = unWrapUserInfo(userInfo);
        if (user != null) {
            System.out.println("Now let's get the userINFO we have build in token!" +
                    "");
            
            System.out.println(user);

        }

    }
}

/**
 * 加密工具类的实现。
 */
class CryptUtils {

    private final static String DES = "DES";
    private static String defaultKey = "";

    // 这里的代码段主要是为了加密用的key大于8位
    static {
        String strKey = "$pNtFSg.nm1$-~-9HQ#^q}t1&:K~=:qxqD3#(FSSFTaH?}A.F{LVEwf>rL|Ib2=@";//测试用
        int len = strKey.length();
        if (len < 8) {
            for (int i = len; i < 8; i++) {
                strKey += "$";
            }
        }
        defaultKey = strKey;
    }

    /**
     * 加密，使用的是本身提供的加密串
     *
     * @param src
     * @return
     */
    public static String encrypt(String src) {
        return encrypt(src, defaultKey);
    }

    /**
     * 解密，使用的是默认提供的解密串
     *
     * @param src
     * @return
     * @throws Exception
     */
    public static String decrypt(String src) throws Exception {
        return decrypt(src, defaultKey);
    }

    /**
     * 数据解密
     *
     * @param data
     * @param key  密钥
     * @return
     * @throws Exception
     */
    public final static String decrypt(String data, String key)
            throws Exception {
        return new String(decrypt(hex2byte(data.getBytes()), key.getBytes()));
    }

    /**
     * 数据加密
     *
     * @param data
     * @param key  密钥
     * @return
     * @throws Exception
     */
    public final static String encrypt(String data, String key) {
        if (data != null)
            try {
                return byte2hex(encrypt(data.getBytes(), key.getBytes()));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        return null;
    }

    /**
     * 加密
     *
     * @param src 数据源
     * @param key 密钥，长度必须是8的倍数
     * @return 返回加密后的数据
     * @throws Exception
     */
    private static byte[] encrypt(byte[] src, byte[] key)
            throws RuntimeException {
        // DES算法要求有一个可信任的随机数源
        try {
            SecureRandom sr = new SecureRandom();
            // 从原始密匙数据创建DESKeySpec对象
            DESKeySpec dks = new DESKeySpec(key);
            // 创建一个密匙工厂，然后用它把DESKeySpec转换成
            // 一个SecretKey对象
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
            SecretKey securekey = keyFactory.generateSecret(dks);
            // Cipher对象实际完成加密操作
            Cipher cipher = Cipher.getInstance(DES);
            // 用密匙初始化Cipher对象
            cipher.init(Cipher.ENCRYPT_MODE, securekey, sr);
            // 现在，获取数据并加密
            // 正式执行加密操作
            return cipher.doFinal(src);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 解密
     *
     * @param src 数据源
     * @param key 密钥，长度必须是8的倍数
     * @return 返回解密后的原始数据
     * @throws Exception
     */
    private static byte[] decrypt(byte[] src, byte[] key)
            throws RuntimeException {
        try {
            // DES算法要求有一个可信任的随机数源
            SecureRandom sr = new SecureRandom();
            // 从原始密匙数据创建一个DESKeySpec对象
            DESKeySpec dks = new DESKeySpec(key);
            // 创建一个密匙工厂，然后用它把DESKeySpec对象转换成
            // 一个SecretKey对象
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
            SecretKey securekey = keyFactory.generateSecret(dks);
            // Cipher对象实际完成解密操作
            Cipher cipher = Cipher.getInstance(DES);
            // 用密匙初始化Cipher对象
            cipher.init(Cipher.DECRYPT_MODE, securekey, sr);
            // 现在，获取数据并解密
            // 正式执行解密操作
            return cipher.doFinal(src);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 二行制转字符串
     *
     * @param b
     * @return
     */
    private static String byte2hex(byte[] b) {
        StringBuilder hs = new StringBuilder();
        String stmp;
        for (int n = 0; b != null && n < b.length; n++) {
            stmp = Integer.toHexString(b[n] & 0XFF);
            if (stmp.length() == 1)
                hs.append('0');
            hs.append(stmp);
        }
        return hs.toString().toUpperCase();
    }

    private static byte[] hex2byte(byte[] b) {
        if ((b.length % 2) != 0)
            throw new IllegalArgumentException();
        byte[] b2 = new byte[b.length / 2];
        for (int n = 0; n < b.length; n += 2) {
            String item = new String(b, n, 2);
            b2[n / 2] = (byte) Integer.parseInt(item, 16);
        }
        return b2;
    }
    
}
