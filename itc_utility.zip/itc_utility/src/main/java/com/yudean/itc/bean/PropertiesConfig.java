package com.yudean.itc.bean;

import java.util.List;
import java.util.Map;

/**
 * 配置对象类
 * @author kchen
 *
 */
public class PropertiesConfig {
	private String name;
	private List<String>  fieldList;
	private Map<String, Map<String, String>> fieldDate;
	
	/**
	 * 配置名称
	 * @return
	 */
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * 定义的配置域
	 * @return
	 */
	public List<String> getFieldList() {
		return fieldList;
	}
	public void setFieldList(List<String> fieldList) {
		this.fieldList = fieldList;
	}
	
	/**
	 * 配置域数据
	 * @return
	 */
	public Map<String, Map<String, String>> getFieldDate() {
		return fieldDate;
	}
	public void setFieldDate(Map<String, Map<String, String>> fieldDate) {
		this.fieldDate = fieldDate;
	}
}
