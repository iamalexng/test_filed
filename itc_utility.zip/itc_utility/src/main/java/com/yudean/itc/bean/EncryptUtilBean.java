package com.yudean.itc.bean;

/**
 * 加密模块Bean
 * @company: gdyd
 * @className: EncryptUtilBean.java
 * @author: kChen
 * @createDate: 2014-9-18
 * @updateUser: kChen
 * @version: 1.0
 */
public class EncryptUtilBean {
	String secretkey;
	String iv;
	String bSecretData;
	public String getSecretkey() {
		return secretkey;
	}
	public void setSecretkey(String secretkey) {
		this.secretkey = secretkey;
	}
	public String getIv() {
		return iv;
	}
	public void setIv(String iv) {
		this.iv = iv;
	}
	public String getbSecretData() {
		return bSecretData;
	}
	public void setbSecretData(String bSecretData) {
		this.bSecretData = bSecretData;
	}
}
