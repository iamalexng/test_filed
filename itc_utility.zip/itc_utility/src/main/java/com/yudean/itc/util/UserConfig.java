package com.yudean.itc.util;

public class UserConfig {
	public String theme;
	public String rows;
	public String type;
}
