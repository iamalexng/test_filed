package com.yudean.itc.util.map;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.yudean.itc.util.json.JsonHelper;

/**
 * Map转换类
 * 
 * @title: {title}
 * @description: {desc}
 * @company: gdyd
 * @className: MapHelper.java
 * @author: kChen
 * @createDate: 2014-8-15
 * @updateUser: kChen
 * @version: 1.0
 */
public class MapHelper {
	private static final Logger logger = Logger.getLogger(MapHelper.class);

	/**
	 * 将Map<String, Object> 装换为JAVABean
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-9-26
	 * @param map
	 * @param clazz
	 * @return
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws InstantiationException:
	 */
	public static <T> T map2Bean(Map<String, Object> map, Class<T> clazz) throws IllegalAccessException, InvocationTargetException,
			InstantiationException {
		T instance = clazz.newInstance();
		BeanUtils.populate(instance, map);
		return instance;
	}

	/**
	 * @description:json转 HashMap，如果其中含有Date，则直接转为long型
	 * @author: fengzt
	 * @createDate: 2014年6月4日
	 * @param dataJson
	 * @return:
	 */
	public static Map<String, Object> jsonToHashMap(String jsonString) throws JsonParseException, JsonMappingException {
		@SuppressWarnings("unchecked")
		HashMap<String, Object> hashMap = JsonHelper.toObject(jsonString, HashMap.class);
		return hashMap;
	}

	/**
	 * @description:bean转hashMap 原有类型都是按类型转换
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param obj
	 * @return:
	 */
	public static Map<String, Object> ObjectToHashMap(Object obj) {
		Field[] field = obj.getClass().getDeclaredFields();
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		for (int i = 0; i < field.length; i++) {
			Field f = field[i];
			f.setAccessible(true);
			try {
				hashMap.put(f.getName(), f.get(obj));
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return hashMap;
	}

	/**
	 * @description:将json转为HashMap，其中的bean的Date类型也会被转为Date
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param jsonString
	 * @param clazz
	 * @return:
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	public static <T> Map<String, Object> fromJsonStringToHashMap(String jsonString, Class<T> clazz) throws JsonParseException, JsonMappingException {
		T bean = JsonHelper.toObject(jsonString, clazz);
		Map<String, Object> hashMap = ObjectToHashMap(bean);
		return hashMap;
	}

	/**
	 * 根据指定的resultMapId获取property-column对应关系
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param daoMapId
	 *            Dao中的reusltMapId
	 * @param path
	 *            xml文件在项目中的相对路径 如"/com/timss/ptw/dao/PtwInfoDao.xml"
	 * @return Map<property,cloumn>
	 */
	public static HashMap<String, String> getPropertyColumnMap(String daoMapId, String path) {
		SAXReader reader = new SAXReader();
		HashMap<String, String> columnProperty = new HashMap<String, String>();
		try {
			// File file = getFile( projectName, fileName );
			InputStream inputStream = getFileInputStream(path);
			if (inputStream == null) {
				logger.error("获取" + path + "失败！");
				return columnProperty;
			}

			// 解决远程读取DTD文件验证超时的问题
			reader.setEntityResolver(new EntityResolver() {
				public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
					return new InputSource(new ByteArrayInputStream("".getBytes()));
				}
			});
			Document doc = reader.read(inputStream);
			Element element = (Element) doc.selectSingleNode("/mapper/resultMap[@id='" + daoMapId + "']");
			if (element != null) {
				@SuppressWarnings("unchecked")
				List<Element> nodes = element.elements();
				for (Element node : nodes) {
					columnProperty.put(node.attributeValue("property"), node.attributeValue("column"));
					columnProperty.put("_" + node.attributeValue("property"), "_" + node.attributeValue("column"));
				}
			} else {
				logger.error("获取" + path + "文件中Id为" + daoMapId + "的resultMap失败！");
				return columnProperty;
			}
			if (inputStream != null) {
				inputStream.close();
				doc.clearContent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return columnProperty;
	}

	/**
	 * 根据指定的resultMapId获取property-column对应关系
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param daoMapId
	 *            Dao中的reusltMapId
	 * @param projectName
	 *            项目名称如ptw/demo
	 * @param fileName
	 *            xml文件的名称
	 * @return Map<property,cloumn>
	 */
	public static HashMap<String, String> getPropertyColumnMap(String daoMapId, String projectName, String fileName) {
		String path = genTimssFilePath(projectName, fileName);
		return getPropertyColumnMap(daoMapId, path);
	}

	/**
	 * 将Property的map转换为column的map
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param propertyMap
	 * @param propertColumnMap
	 *            对应关系的Map
	 * @return column的 HashMap
	 */
	public static HashMap<String, Object> fromPropertyToColumnMap(Map<String, Object> propertyMap, Map<String, String> propertColumnMap) {
		HashMap<String, Object> columnMap = new HashMap<String, Object>();
		Iterator<Entry<String, Object>> iter = propertyMap.entrySet().iterator();
		while (iter.hasNext()) {
			Entry<String, Object> entry = (Entry<String, Object>) iter.next();
			if (propertColumnMap.get(entry.getKey()) != null) {
				columnMap.put(propertColumnMap.get(entry.getKey()), entry.getValue());
			} else {
				columnMap.put((String) entry.getKey(), entry.getValue());
			}
		}
		return columnMap;
	}

	/**
	 * 将Property的map转换为column的map
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param propertyMap
	 * @param daoMapId
	 *            Dao中resultMap的Id
	 * @param projectName
	 *            项目名称如ptw/demo
	 * @param fileName
	 *            xml文件的名称
	 * @return column的 HashMap
	 */
	public static HashMap<String, Object> fromPropertyToColumnMap(Map<String, Object> propertyMap, String daoMapId, String projectName,
			String fileName) {
		HashMap<String, String> propertColumnMap = getPropertyColumnMap(daoMapId, projectName, fileName);
		return fromPropertyToColumnMap(propertyMap, propertColumnMap);
	}

	/**
	 * 将Property的map转换为column的map
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-6-23
	 * @param propertyMap
	 * @param daoMapId
	 *            Dao中resultMap的Id
	 * @param path
	 *            xml文件在项目中的相对路径 如"/com/timss/ptw/dao/PtwInfoDao.xml"
	 * @return column的 HashMap
	 */
	public static HashMap<String, Object> fromPropertyToColumnMap(Map<String, Object> propertyMap, String daoMapId, String path) {
		HashMap<String, String> propertColumnMap = getPropertyColumnMap(daoMapId, path);
		return fromPropertyToColumnMap(propertyMap, propertColumnMap);
	}

	/**
	 * 生成Timss专用的XML文件地址地址
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-9-25
	 * @param projectName
	 * @param fileName
	 * @return:
	 */
	private static String genTimssFilePath(String projectName, String fileName) {
		return "/com/timss/" + projectName + "/dao/" + fileName + ".xml";
	}

	/**
	 * 获取jar包中的输入流
	 * 
	 * @description:
	 * @author: 周保康
	 * @createDate: 2014-9-25
	 * @param path
	 *            xml文件在项目中的相对路径 如"/com/timss/ptw/dao/PtwInfoDao.xml"
	 * @return:
	 */
	private static InputStream getFileInputStream(String path) {
		InputStream inputStream = MapHelper.class.getResourceAsStream(path);
		return inputStream;
	}
}
