package com.yudean.itc.util;

import java.lang.reflect.Field;

import org.apache.log4j.Logger;

/**
 * javabean 相关处理工具类
 * 
 * @author kchen
 * 
 */
public class JavaBeanHelper {
	private static final Logger LOG = Logger.getLogger(JavaBeanHelper.class);

	private JavaBeanHelper() {
		
	}

	/**
	 * 转移预编译好的前端编码
	 * 
	 * @param t
	 * @return
	 */
	public static <T> T transDefineMuliteCode(T t) {
		Class<?> clazz = t.getClass();
		return t;
	}
}
