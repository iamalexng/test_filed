package com.yudean.itc.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 时间帮助工具
 * @company: gdyd
 * @className: DateHelper.java
 * @author: kChen
 * @createDate: 2014-9-4
 * @updateUser: kChen
 * @version: 1.0
 */
public class DateHelper {
	private static final String YYYY_MM_DD_HH_MI_SS = "yyyy-MM-dd HH:mm:ss";
	private static final String YYYY_MM_DD_HH_MI = "yyyy-MM-dd HH:mm";
	private static final String YYYY_MM_DD = "yyyy-MM-dd";
	/**
	 * 返回当前时间。<br/>
	 * 使用全局方法返回当前时间，以方便系统测试。
	 * @return 当前时间
	 */
	public static Date now(){
		return new Date(System.currentTimeMillis());
	}
	
	public static String dateNow(){
		DateFormat df = new SimpleDateFormat(YYYY_MM_DD);
		String rtn = df.format(now());
		return rtn;
	}
	
	public static String timeNow(){
		DateFormat df = new SimpleDateFormat(YYYY_MM_DD_HH_MI_SS);
		String rtn = df.format(now());
		return rtn;
	}
	
	public static String formatTime(Date date){
		if(date==null){
			return "";
		}
		DateFormat df = new SimpleDateFormat(YYYY_MM_DD_HH_MI_SS);
		return df.format(date);
	}
	
	public static String formatTimeAtMin(Date date){
		if(date==null){
			return "";
		}
		DateFormat df = new SimpleDateFormat(YYYY_MM_DD_HH_MI);
		return df.format(date);
	}
}
