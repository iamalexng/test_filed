package com.yudean.itc.util;

import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.security.Security;

import javax.crypto.KeyGenerator;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.UrlBase64;

import com.yudean.itc.bean.EncryptUtilBean;

/**
 * 加密工具类， 目前提供： DES固定加密， 异或流密码加密， AES密码本模式加密， AES一次一密加密
 * 
 * @company: gdyd
 * @className: EncryptUtil.java
 * @author: kChen
 * @createDate: 2014-9-18
 * @updateUser: kChen
 * @version: 1.0
 */
public class EncryptUtil {
	// 密钥 暂时这样标记，今后增加到配置文件中
	private final static byte[] KRY_BYTES = { 0x11, 0x22, 0x4F, 0x58, (byte) 0x88, 0x10, 0x40, 0x38, 0x28, 0x25, 0x79, 0x51, (byte) 0xCB,
			(byte) 0xDD, 0x55, 0x66, 0x77, 0x29, 0x74, (byte) 0x98, 0x30, 0x40, 0x36, (byte) 0xE2 };

	// IV 随机向量，暂时这样设置，今后增加到配置文件中
	private final static byte[] IV_B = { 0x12, 0x34, 0x56, 0x78, (byte) 0x90, (byte) 0xab, (byte) 0xcd, (byte) 0xef };

	// 密钥生成算法

	private static final String KeyALGORITHMAES = "AES";// AES标准密钥算法

	// 算法
	private static final String ALGORITHM = "DESede";

	private static final String ALGORITHMAES = "AES/CBC/NoPadding";// AES/CBC流密码本模式/块不足时无数据填充

	// 算法提供者

	private static final String ProviderAES = "BC";// BouncyCastle

	// 种子序列
	private static final String[] torrentseed = { "S", "O", "F", "T", "H", "I", "G", "s", "_", "f", "a", "2", "3" };

	// 加密强度
	private static final int AES_BYTE_SIZE = 16;

	private static final int BYTE_LENGTH = 8;

	static {
		// 初始化加密规范
		Security.addProvider(new BouncyCastleProvider());
	}

	private EncryptUtil() {
	}

	/**
	 * 进行加密处理
	 * 
	 * @param oriString
	 *            String 加密前的字符串
	 * @return String 加密后的字符串
	 */
	@SuppressWarnings("restriction")
	public static String getEncryptString(String oriString) {
		if (oriString == null || oriString.equals("")) {
			return oriString;
		}
		String result = "";
		byte[] value = encryptMode(oriString.getBytes());
		if (value != null) {
			result = (new sun.misc.BASE64Encoder()).encode(value);
		}
		return result;
	}

	/**
	 * 进行解密处理
	 * 
	 * @param oriString
	 *            String 解密前的字符串
	 * @return String 解密后的字符串
	 */
	public static String getDecryptString(String oriString) {
		if (oriString == null || oriString.equals("")) {
			return oriString;
		}
		String result = "";
		try {
			@SuppressWarnings("restriction")
			byte[] value = (new sun.misc.BASE64Decoder()).decodeBuffer(oriString);
			value = decryptMode(value);
			if (value != null) {
				result = new String(value);
			}
		} catch (Exception e) {
		}
		return result;
	}

	/**
	 * 二进制加密
	 * 
	 * @param src
	 * @return byte[]
	 */
	public static byte[] encryptMode(byte[] src) {
		try {

			SecretKey deskey = new SecretKeySpec(KRY_BYTES, ALGORITHM);
			Cipher c1 = Cipher.getInstance("DESede/CFB/NoPadding");

			IvParameterSpec iv = new IvParameterSpec(IV_B);
			c1.init(Cipher.ENCRYPT_MODE, deskey, iv);
			return c1.doFinal(src);
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 二进制解密
	 * 
	 * @param src
	 * @return byte[]
	 */
	public static byte[] decryptMode(byte[] src) {
		try {
			SecretKey deskey = new SecretKeySpec(KRY_BYTES, ALGORITHM);
			Cipher c1 = Cipher.getInstance("DESede/CFB/NoPadding");
			IvParameterSpec iv = new IvParameterSpec(IV_B);
			c1.init(Cipher.DECRYPT_MODE, deskey, iv);
			return c1.doFinal(src);
		} catch (java.lang.Exception e) {
		}
		return null;
	}

	public static void main(String[] args) {
		System.out.println(getDecryptString("UTI0gKxG"));
	}

	/**
	 * base64编码
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-9-19
	 * @param sSectext
	 * @return
	 * @throws Exception:
	 */
	public static String UrlBase64Encode(String sSectext) throws Exception{
		byte[] bSectextByte = sSectext.getBytes(Charset.defaultCharset());
		byte[] bBase64Byte = UrlBase64.encode(bSectextByte);
		return new String(bBase64Byte, Charset.defaultCharset());
	}
	
	/**
	 * base64解码
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-9-19
	 * @param sSectext
	 * @return
	 * @throws Exception:
	 */
	public static String UrlBase64Decode(String sSectext) throws Exception{
		byte[] bSectextByte = sSectext.getBytes(Charset.defaultCharset());
		byte[] bBase64Byte = UrlBase64.decode(bSectextByte);
		return new String(bBase64Byte, Charset.defaultCharset());
	}
	
	/**
	 * 利用宏定义密钥生成密文
	 * 
	 * @param sSectext
	 *            明文
	 * @return
	 */
	public static String OR_byteEncryptLocal(String sSectext) throws Exception {
		return OR_byteEncrypt(sSectext, KRY_BYTES);
	}

	/**
	 * 利用宏定义密钥还原明文
	 * 
	 * @param sSectext
	 *            明文
	 * @return
	 */
	public static String OR_byteDecryptLocal(String sSectext) throws Exception {
		return OR_byteDecrypt(sSectext, KRY_BYTES);
	}

	/**
	 * 流异或加解密,生成伪随机序列(不依赖外部编码)
	 * 
	 * @param sPlaintext
	 *            明文
	 * @param iv
	 *            对称密钥
	 * @return 伪随机序列
	 */
	public static String OR_byteEncrypt(String sSectext, byte[] key) throws Exception {
		byte[] bsec = sSectext.getBytes(Charset.defaultCharset().name());
		int ivStep = 0;
		for (int step = 0; bsec.length > step; step++) {
			bsec[step] = (byte) (bsec[step] ^ key[ivStep++]);
			ivStep = key.length == ivStep ? 0 : ivStep;
		}
		return new String(UrlBase64.encode(bsec), Charset.defaultCharset().name());
	}

	/**
	 * 流异或解密,还原伪随机序列(不依赖外部编码)
	 * 
	 * @param sSectext
	 *            BASE64编码的伪随机序列
	 * @param iv
	 *            对称密钥
	 * @return 明文
	 */
	public static String OR_byteDecrypt(String sSectext, byte[] key) throws Exception {
		int ivStep = 0;
		byte[] bBase64 = UrlBase64.decode(sSectext);
		for (int i = 0; bBase64.length > i; i++) {
			bBase64[i] = (byte) (bBase64[i] ^ key[ivStep++]);
			ivStep = key.length == ivStep ? 0 : ivStep;
		}
		return new String(bBase64, Charset.defaultCharset().name());
	}

	/**
	 * AES一次一密加密数据加密（不依赖外部编码）
	 * 
	 * @param sData
	 *            加密明文
	 * @return （BASE64编码）first：密文。second：随机密钥。third：加密模式随机数
	 * @throws Exception
	 */
	public static EncryptUtilBean AESEncrypt(String sData) throws Exception {
		// 新增加密规范
		// Provider[] pros = Security.getProviders();// 安全支持列表
		byte[] secretkey = getSecretKeyAESUtil(null);// 获取密钥
		byte[] iv = SecureRandom.getSeed(AES_BYTE_SIZE);// 获取密码模式向量
		// 加密块填充 ：AES_BYTE_SIZE进制块
		sData = paddingData(sData, 0);
		// AES/CBC密码本加密
		byte[] bSecretData = AesEncryptUtil(sData.getBytes(Charset.defaultCharset().name()), secretkey, iv);
		EncryptUtilBean encryptUtilBean = new EncryptUtilBean();
		encryptUtilBean.setSecretkey(new String(UrlBase64.encode(bSecretData), Charset.defaultCharset().name()));
		encryptUtilBean.setIv(new String(UrlBase64.encode(iv), Charset.defaultCharset().name()));
		encryptUtilBean.setbSecretData(new String(UrlBase64.encode(bSecretData), Charset.defaultCharset().name()));
		return encryptUtilBean;
	}

	/**
	 * AES一次一密数据解密（不依赖外部编码）
	 * 
	 * @param sDataBase64
	 *            密文
	 * @param sKeyBase64
	 *            密钥
	 * @param sIvBase64
	 *            模式向量
	 * @return 明文
	 * @throws Exception
	 */
	public static String AESDecrypt(String sDataBase64, String sKeyBase64, String sIvBase64) throws Exception {
		// sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();
		byte[] sectetdata = UrlBase64.decode(sDataBase64);
		byte[] secretkey = UrlBase64.decode(sKeyBase64);
		byte[] iv = UrlBase64.decode(sIvBase64);
		byte[] bData = AesDecryptUtil(sectetdata, secretkey, iv);
		return paddingData(new String(bData, Charset.defaultCharset().name()), 1);
	}

	/**
	 * 生成AES密钥
	 * 
	 * @param seed
	 *            密钥种子
	 * @throws Exception
	 */
	public static byte[] getSecretKeyAESUtil(String seed) throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyALGORITHMAES);
		SecureRandom secureRandom;
		if (seed != null && !"".equals(seed)) {
			secureRandom = new SecureRandom(seed.getBytes());
		} else {
			secureRandom = new SecureRandom();
		}
		keyGenerator.init(AES_BYTE_SIZE * BYTE_LENGTH, secureRandom);
		SecretKey secretKey = keyGenerator.generateKey();
		return secretKey.getEncoded();
	}

	/**
	 * AES加密（CBC）
	 * 
	 * @param sEData
	 *            加密明文
	 * @param key
	 *            加密密钥
	 * @param iv
	 *            加密模式向量
	 * @return
	 * @throws Exception
	 */
	public static byte[] AesEncryptUtil(byte[] bEData, byte[] key, byte[] iv) throws Exception {
		SecretKeySpec secretKeySpec = new SecretKeySpec(key, KeyALGORITHMAES);
		Cipher cipher = Cipher.getInstance(ALGORITHMAES, ProviderAES);
		IvParameterSpec Iv = new IvParameterSpec(iv);
		cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, Iv);
		return cipher.doFinal(bEData);
	}

	/**
	 * AES解密（CBC）
	 * 
	 * @param bEData
	 *            密文
	 * @param key
	 *            密钥
	 * @param iv
	 *            模式向量
	 * @return
	 * @throws Exception
	 */
	public static byte[] AesDecryptUtil(byte[] bEData, byte[] key, byte[] iv) throws Exception {
		SecretKeySpec secretKeySpec = new SecretKeySpec(key, KeyALGORITHMAES);
		Cipher cipher = Cipher.getInstance(ALGORITHMAES, ProviderAES);
		IvParameterSpec Iv = new IvParameterSpec(iv);
		cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, Iv);
		return cipher.doFinal(bEData);
	}

	/**
	 * 生成和还原加密块填充数据
	 * 
	 * @description:
	 * @author: kChen
	 * @createDate: 2014-9-18
	 * @param CursData
	 * @param mode
	 *            0填充 1还原
	 * @return
	 * @throws Exception
	 *             :
	 */
	private static String paddingData(String CursData, int mode) throws Exception {
		String sReData = "";
		final String sReplaceToke = "[|ReplaceData|]";
		final String sBegFlag = "<";
		final String sEndFlag = ">";
		if (0 == mode) {
			final int iCodelength = CursData.length();
			final int iLostlength = ((int) iCodelength / AES_BYTE_SIZE + 1) * AES_BYTE_SIZE - iCodelength;
			if (1 == iLostlength) {
				CursData += sBegFlag;
			} else if (2 == iLostlength) {
				CursData += sBegFlag + sEndFlag;
			} else if (0 == iLostlength) {
				// nothing
			} else {
				final int iOldDataLength = CursData.length();
				int irandom = new Double(Math.ceil(Math.round(Math.random() * (iOldDataLength - 1)))).intValue();// yxInterFalceFrontConfirm
				// CursData = CursData.substring(0, irandom) + sBegFlag +
				// sReplaceToke + sEndFlag + CursData.substring(irandom,
				// iOldDataLength);
				CursData = StringHelper.concat(CursData.substring(0, irandom), sBegFlag, sReplaceToke, sEndFlag,
						CursData.substring(irandom, iOldDataLength));
				String repStr = "";
				for (int index = 0; iLostlength - 2 > index; index++) {
					repStr += torrentseed[new Double(Math.ceil(Math.round(Math.random() * (torrentseed.length - 1)))).intValue()];
				}
				sReData = CursData.replace(sReplaceToke, repStr);
			}
		} else {
			final int BegPos = CursData.indexOf(sBegFlag);
			if (-1 == BegPos) {
				sReData = CursData;
			} else {
				final int EndPos = CursData.indexOf(sEndFlag, BegPos);
				if (-1 == EndPos) {
					sReData = CursData.replace(sBegFlag, "");
				} else if (0 < EndPos && EndPos == BegPos + 1) {
					sReData = CursData.replace(sBegFlag + sEndFlag, "");
				} else {
					final String sReplaceData = CursData.substring(BegPos, EndPos + 1);
					sReData = CursData.replace(sReplaceData, "");
				}
			}

		}
		return sReData;
	}
}
