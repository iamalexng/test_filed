package com.yudean.itc.util;

import java.util.Map;

import org.apache.log4j.Logger;

import com.yudean.esb.sms.SMSClient;

public class SmsSendUtils {
	private static final Logger log = Logger.getLogger(SmsSendUtils.class);
	static SMSClient Smshandler = null;
	static{
		InitSmsSendUtils();
	}
	static public Boolean InitSmsSendUtils() {
		log.info("使用默认的短信配置。");
		Boolean ret = false;
		try {
			String host = ApplicationConfig.getConfig("sms.host");
			String name = ApplicationConfig.getConfig("sms.name");
			String pwd = ApplicationConfig.getConfig("sms.password");
			String apiId = ApplicationConfig.getConfig("sms.apiId");
			String dbName = ApplicationConfig.getConfig("sms.dbname");
			Smshandler = new SMSClient(host, name, pwd, apiId, dbName);
			ret = true;
		} catch (Exception e) {
			log.error("初始化短信工具异常，当前不能发送短信", e);
		}
		return ret;
	}
	
	static public SMSClient InitSmsSendUtils(String siteId) {
		SMSClient smsClient = null;
		try {
			Map<String, String> result = JdbcUtil.getSiteConfig(siteId);
			//String isSend = result.get("SMS_IS_SEND");
			//if("1".equals(isSend)){
			String host = result.get("SMS_HOST");
			String name = result.get("SMS_NAME");
			String pwd = result.get("SMS_PASSWORD");
			String apiId = result.get("SMS_APIID");
			String dbName = result.get("SMS_DBNAME");
			log.info(siteId + "站点短信配置信息为：" + "host:" + host + "//name:" + name
					+ "//apiId：" + apiId + "//dbname:" + dbName);
			smsClient = new SMSClient(host, name, pwd, apiId, dbName);
			log.info("init siteid success.");
			//}else{
			//	log.info("当前站点的短信配置不为1，不发送短信.");
			//}

		} catch (Exception e) {
			log.error("初始化短信工具异常，当前不能发送短信", e);
		}
		return smsClient;
	}

	static public void sendSms(String[] recipient, String content) throws Exception {
		Boolean isSend = true;
		if(null == Smshandler){
			isSend = InitSmsSendUtils();
		}
		if(isSend){
			Smshandler.sendSMS(recipient, content);
		}
	}
	
	static public void sendSms(String[] recipient, String siteId, String content) throws Exception {
		
		log.info("当前站点id为" + siteId);
		if(siteId == null){
			log.info("使用默认配置发送短信。");
			sendSms(recipient, content);
		}else{
			//不使用静态变量Smshandler，每次调用都需要查询站点对应的帐号密码，传给短信平台供统计使用。
			log.info(siteId + "站点即将发送短信.");
			SMSClient smsClient  = InitSmsSendUtils(siteId);
			if(smsClient != null){
				smsClient.sendSMS(recipient, content);
			}
		}
	}

}
