package com.yudean.itc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class JdbcUtil {

	static Connection conn = null;
	private static final Logger LOGGER = Logger.getLogger(JdbcUtil.class); 

	public static Connection getConnectionByJDBC() {
        
		try {
			if(conn == null || conn.isClosed()){
				try {
			        //装载驱动包类
			        Class.forName(ApplicationConfig.getConfig("jdbc.driver"));
			        }catch(ClassNotFoundException e) {
			        	LOGGER.error("装载驱动包出现异常!请查正！");
			            e.printStackTrace();
			        }
			    try{
			         conn = DriverManager.getConnection(ApplicationConfig.getConfig("jdbc.url"),ApplicationConfig.getConfig("jdbc.username"),
			        		 ApplicationConfig.getConfig("jdbc.password"));
			    }catch(SQLException e) {
			    	LOGGER.error("链接数据库发生异常!");
			        e.printStackTrace();
			    }
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
        return conn;
    }

	public static Map<String, String> getSiteConfig(String siteId) {
		
		Map<String, String> result = new HashMap<String, String>();
		PreparedStatement preparedStatement;  
		String sql = "SELECT SITE_ID,SMS_HOST,SMS_NAME,SMS_PASSWORD,SMS_APIID,SMS_DBNAME,SMS_IS_SEND FROM SEC_SITE WHERE SITE_ID = ?";
		getConnectionByJDBC();
		try {
			// 创建一个jdbc声明
			preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setObject(1, siteId);
			// 执行查询
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				result.put("SITE_ID", rs.getString("SITE_ID"));
				result.put("SMS_HOST", rs.getString("SMS_HOST"));
				result.put("SMS_NAME", rs.getString("SMS_NAME"));
				result.put("SMS_PASSWORD", rs.getString("SMS_PASSWORD"));
				result.put("SMS_APIID", rs.getString("SMS_APIID"));
				result.put("SMS_DBNAME", rs.getString("SMS_DBNAME"));
				result.put("SMS_IS_SEND", rs.getString("SMS_IS_SEND"));
			}
			return result;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return null;
		} finally {
			// 预防性关闭连接（避免异常发生时在try语句块关闭连接没有执行)
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		
		System.out.println(ApplicationConfig.getConfig("jdbc.driver"));
         
		Map<String, String> result = JdbcUtil.getSiteConfig("CWC");
		for(Map.Entry<String, String> entry: result.entrySet()) {
			 System.out.print(entry.getKey() + ":" + entry.getValue() + "\t");
			}
	}
}