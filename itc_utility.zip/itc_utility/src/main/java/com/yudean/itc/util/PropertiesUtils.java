package com.yudean.itc.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * 通用PropertiesUtils读写工具
 * @title: {title}
 * @description: {desc}
 * @company: gdyd
 * @className: PropertiesUtils.java
 * @author: kChen
 * @createDate: 2014-9-10
 * @updateUser: kChen
 * @version: 1.0
 */
public class PropertiesUtils {
	private static final Logger log = Logger.getLogger(PropertiesUtils.class);

	/**
	 * @description:获取properties文件
	 * @author: 890166
	 * @createDate: 2014-8-16
	 * @param key
	 * @return:
	 */
	public static Properties getProperties(String propertiesPath) {
		Properties p = null;
		InputStream in = null;
		try {
			in = Thread.currentThread().getContextClassLoader().getResourceAsStream(propertiesPath);
			p = new Properties();
			p.load(in);
		} catch (Exception e) {
			log.error("读取" + propertiesPath + "异常", e);
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return p;
	}

	public static String getPropertiesItem(String key, String propertiesPath) {
		Properties p = getProperties(propertiesPath);
		return p.getProperty(key);
	}
}
