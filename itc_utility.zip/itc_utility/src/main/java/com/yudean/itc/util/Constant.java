package com.yudean.itc.util;

public class Constant {
	public static final String secUser = "user";
	public static final String userConf = "user";
	public static final String jspPath  = "jsp/";
	public static final String resBase = "";
	public static final String sysHashCls = "com.yudean.itc.util.MD5";
	public static final String sysHashMethod = "GetMD5Code";
	public static final String syncHashCls = "com.yudean.itc.util.MD5";
	public static final String syncHashMethod = "GetMD5Code";
	public static String basePath = ""; 
	public static final int DEL_KEY_EXPIRES = 1800;
}
