package com.yudean.itc.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 890157 on 2016/6/1.
 */
public class PrivEuTreeNode extends EuTreeNode{
    private List<PrivOrigin> origins;

    public void addOrigin(PrivOrigin origin){
        if(origins == null){
            origins = new ArrayList<PrivOrigin>();
        }
        origins.add(origin);
    }

    public PrivEuTreeNode(String title, String id) {
        super(title, id);
    }

    public List<PrivOrigin> getOrigins(){
        return origins;
    }
}
