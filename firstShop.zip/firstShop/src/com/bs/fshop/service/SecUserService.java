package com.bs.fshop.service;

import com.bs.fshop.po.SecUser;

/**
 * @title:
 * @descrption: 
 * @team:
 * @className SecUserService.java
 * @author 吴圣(890160)
 * @createDate 创建时间：2015-9-29 上午10:37:16
 * 
 */
public interface SecUserService {
	
	
	
	SecUser selectByPrimaryKey(Integer id);

}
